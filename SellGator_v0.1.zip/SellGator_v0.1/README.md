# SellGator v0.1 (MVP)
Instructions d'installation et de test du logiciel.