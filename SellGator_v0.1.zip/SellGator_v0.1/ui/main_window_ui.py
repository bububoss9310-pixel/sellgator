# -*- coding: utf-8 -*-
from PySide6.QtCore import *
from PySide6.QtGui import *
from PySide6.QtWidgets import *


class Ui_MainWindow(object):
    def setupUi(self, MainWindow):
        MainWindow.setObjectName("MainWindow")
        MainWindow.resize(1250, 800)

        # ---------- Conteneur principal ----------
        self.central_widget = QWidget(MainWindow)
        MainWindow.setCentralWidget(self.central_widget)
        self.root = QVBoxLayout(self.central_widget)
        self.root.setContentsMargins(18, 18, 18, 18)
        self.root.setSpacing(10)

        # ---------- Header supérieur ----------
        self.header = QHBoxLayout()
        self.title = QLabel("SellGator – Point de vente")
        self.title.setStyleSheet("font-size: 22px; font-weight: 800; color: white;")
        self.label_user = QLabel("Connecté en tant que : …")
        self.label_user.setAlignment(Qt.AlignRight | Qt.AlignVCenter)
        self.label_user.setStyleSheet("color: #cfcfcf;")

        self.logout_button = QPushButton("Se déconnecter")
        self.logout_button.setMinimumHeight(34)
        self.logout_button.setCursor(Qt.PointingHandCursor)
        self.logout_button.setStyleSheet("""
            QPushButton {
                background:#8B0000; color:white; border:none;
                border-radius:6px; padding:6px 12px; font-weight:600;
            }
            QPushButton:hover { background:#B22222; }
        """)

        self.header.addWidget(self.title, 2)
        self.header.addWidget(self.label_user, 1)
        self.header.addWidget(self.logout_button)
        self.root.addLayout(self.header)

        # ---------- Onglets ----------
        self.tabs = QTabWidget()
        self.root.addWidget(self.tabs)

        # -------------------------------------------------------------------
        # 📦 CATALOGUE (FRONT)
        # -------------------------------------------------------------------
        self.tab_catalogue = QWidget()
        self.tabs.addTab(self.tab_catalogue, "📦  Catalogue")
        cat_layout = QVBoxLayout(self.tab_catalogue)
        cat_layout.setContentsMargins(10, 10, 10, 10)
        cat_layout.setSpacing(10)

        # --- Barre supérieure du catalogue (seulement navigation front) ---
        top_bar = QHBoxLayout()
        self.btn_prev_section = QPushButton("⟪")
        self.btn_next_section = QPushButton("⟫")
        for b in (self.btn_prev_section, self.btn_next_section):
            b.setFixedSize(36, 36)
            b.setCursor(Qt.PointingHandCursor)
            b.setStyleSheet("""
                QPushButton {
                    background:#2A2A2A; color:white; font-weight:700;
                    border:1px solid #3a3a3a; border-radius:6px;
                }
                QPushButton:hover { background:#3A3A3A; }
            """)

        self.label_breadcrumb = QLabel("📦 Catalogue")
        self.label_breadcrumb.setStyleSheet("font-size:15px; color:white; font-weight:600;")
        self.label_breadcrumb.setAlignment(Qt.AlignCenter)

        self.btn_back_nav = QPushButton("⬅️ Retour")
        self.btn_back_nav.setMinimumHeight(34)
        self.btn_back_nav.setCursor(Qt.PointingHandCursor)
        self.btn_back_nav.setStyleSheet("""
            QPushButton {
                background:#2A2A2A; color:white; border:1px solid #3a3a3a;
                border-radius:6px; padding:5px 10px;
            }
            QPushButton:hover { background:#3A3A3A; }
        """)

        top_bar.addWidget(self.btn_prev_section)
        top_bar.addStretch(1)
        top_bar.addWidget(self.label_breadcrumb, 3)
        top_bar.addStretch(1)
        top_bar.addWidget(self.btn_next_section)
        top_bar.addWidget(self.btn_back_nav)
        cat_layout.addLayout(top_bar)

        # --- Grille d'affichage du catalogue ---
        self.scroll_catalogue = QScrollArea()
        self.scroll_catalogue.setWidgetResizable(True)
        cat_layout.addWidget(self.scroll_catalogue)

        self.catalogue_container = QWidget()
        self.grid_catalogue = QGridLayout(self.catalogue_container)
        self.grid_catalogue.setSpacing(20)
        self.grid_catalogue.setContentsMargins(20, 20, 20, 20)
        self.scroll_catalogue.setWidget(self.catalogue_container)

        # -------------------------------------------------------------------
        # ⚙️ PARAMÈTRES / CATALOGUE (BACK-OFFICE)
        # -------------------------------------------------------------------
        self.tab_admin = QWidget()
        self.tabs.addTab(self.tab_admin, "⚙️  Paramètres / Catalogue")
        admin_layout = QVBoxLayout(self.tab_admin)
        admin_layout.setContentsMargins(10, 10, 10, 10)
        admin_layout.setSpacing(10)

        # Barre titre admin
        admin_title_bar = QHBoxLayout()
        self.lbl_admin_title = QLabel("Gestion du catalogue (Catégories → Sous-catégories → Rubriques → Produits)")
        self.lbl_admin_title.setStyleSheet("font-size:16px; color:white; font-weight:700;")
        admin_title_bar.addWidget(self.lbl_admin_title)
        admin_layout.addLayout(admin_title_bar)

        # Splitter : Arborescence (gauche) / Détails (droite)
        splitter = QSplitter()
        splitter.setOrientation(Qt.Horizontal)
        admin_layout.addWidget(splitter, 1)

        # --- Arbre hiérarchique à gauche ---
        left = QWidget()
        left_layout = QVBoxLayout(left)
        left_layout.setContentsMargins(0, 0, 0, 0)
        left_layout.setSpacing(8)

        self.treeCatalog = QTreeWidget()
        self.treeCatalog.setHeaderLabels(["Élément", "Type", "ID"])
        self.treeCatalog.setColumnWidth(0, 260)
        self.treeCatalog.setStyleSheet("""
            QTreeWidget { background:#202020; color:#EEE; border:1px solid #333; border-radius:8px; }
            QTreeView::item:selected { background:#2e2e2e; }
        """)
        left_layout.addWidget(self.treeCatalog)

        # Boutons CRUD
        crud_bar = QHBoxLayout()
        self.btn_admin_add = QPushButton("➕ Ajouter")
        self.btn_admin_rename = QPushButton("✏️ Renommer")
        self.btn_admin_delete = QPushButton("🗑️ Supprimer")
        for b in (self.btn_admin_add, self.btn_admin_rename, self.btn_admin_delete):
            b.setMinimumHeight(32)
            b.setCursor(Qt.PointingHandCursor)
            b.setStyleSheet("""
                QPushButton {
                    background:#2A2A2A; color:white; border:1px solid #3a3a3a;
                    border-radius:6px; padding:5px 10px;
                }
                QPushButton:hover { background:#3A3A3A; }
            """)
        crud_bar.addWidget(self.btn_admin_add)
        crud_bar.addWidget(self.btn_admin_rename)
        crud_bar.addWidget(self.btn_admin_delete)
        left_layout.addLayout(crud_bar)

        splitter.addWidget(left)

        # --- Panneau de détails à droite ---
        right = QWidget()
        right_layout = QVBoxLayout(right)
        right_layout.setContentsMargins(0, 0, 0, 0)
        right_layout.setSpacing(8)

        self.group_details = QGroupBox("Détails sélection")
        form = QFormLayout(self.group_details)
        form.setLabelAlignment(Qt.AlignLeft)

        self.edit_name = QLineEdit()
        self.edit_image_path = QLineEdit()
        self.edit_image_path.setReadOnly(True)
        self.btn_choose_image = QPushButton("Choisir une image…")
        img_row = QHBoxLayout()
        img_row.addWidget(self.edit_image_path, 1)
        img_row.addWidget(self.btn_choose_image)

        # Champs prix (utiles pour PRODUIT)
        self.spin_buy = QDoubleSpinBox()
        self.spin_buy.setRange(0, 1_000_000)
        self.spin_buy.setDecimals(4)
        self.spin_buy.setSuffix(" €")
        self.spin_sell = QDoubleSpinBox()
        self.spin_sell.setRange(0, 1_000_000)
        self.spin_sell.setDecimals(4)
        self.spin_sell.setSuffix(" €")
        self.spin_tva = QDoubleSpinBox()
        self.spin_tva.setRange(0, 100)
        self.spin_tva.setDecimals(2)
        self.spin_tva.setSuffix(" %")

        form.addRow("Nom :", self.edit_name)
        form.addRow("Image :", img_row)
        form.addRow("Prix d'achat (HT) :", self.spin_buy)
        form.addRow("Prix de vente (HT) :", self.spin_sell)
        form.addRow("TVA :", self.spin_tva)

        right_layout.addWidget(self.group_details)

        # Boutons d'action détails
        details_bar = QHBoxLayout()
        self.btn_save_details = QPushButton("💾 Enregistrer")
        self.btn_export_csv = QPushButton("⇩ Export CSV")
        self.btn_import_csv = QPushButton("⇧ Import CSV")
        for b in (self.btn_save_details, self.btn_export_csv, self.btn_import_csv):
            b.setMinimumHeight(34)
            b.setCursor(Qt.PointingHandCursor)
            b.setStyleSheet("""
                QPushButton {
                    background:#2A2A2A; color:white; border:1px solid #3a3a3a;
                    border-radius:6px; padding:5px 10px;
                }
                QPushButton:hover { background:#3A3A3A; }
            """)
        details_bar.addWidget(self.btn_save_details)
        details_bar.addStretch(1)
        details_bar.addWidget(self.btn_export_csv)
        details_bar.addWidget(self.btn_import_csv)
        right_layout.addLayout(details_bar)

        splitter.addWidget(right)
        splitter.setStretchFactor(0, 3)
        splitter.setStretchFactor(1, 5)

        # -------------------------------------------------------------------
        # 🧾 VENTE / FACTURATION
        # -------------------------------------------------------------------
        self.tab_vente = QWidget()
        self.tabs.addTab(self.tab_vente, "🧾  Vente / Facturation")

        vente_layout = QHBoxLayout(self.tab_vente)
        vente_layout.setContentsMargins(6, 10, 6, 6)
        vente_layout.setSpacing(12)

        # --- Ticket à gauche ---
        left_col = QVBoxLayout()
        client_bar = QHBoxLayout()
        self.label_selected_client = QLabel("Client : Aucun (particulier)")
        self.btn_select_client = QPushButton("Sélectionner un client")
        self.btn_new_client = QPushButton("Nouveau client")
        for b in (self.btn_select_client, self.btn_new_client):
            b.setMinimumHeight(30)
        client_bar.addWidget(self.label_selected_client, 1)
        client_bar.addWidget(self.btn_select_client)
        client_bar.addWidget(self.btn_new_client)
        left_col.addLayout(client_bar)

        self.tableTicket = QTableWidget(0, 7)
        self.tableTicket.setHorizontalHeaderLabels(
            ["Désignation", "Qté", "Prix HT", "TVA %", "Total HT", "Total TVA", "Total TVAC"]
        )
        self.tableTicket.horizontalHeader().setStretchLastSection(True)
        self.tableTicket.setAlternatingRowColors(True)
        left_col.addWidget(self.tableTicket)

        row_btns = QHBoxLayout()
        self.btn_ticket_add = QPushButton("Ajouter un article")
        self.btn_ticket_edit = QPushButton("Modifier la ligne")
        self.btn_ticket_remove = QPushButton("Supprimer la ligne")
        for b in (self.btn_ticket_add, self.btn_ticket_edit, self.btn_ticket_remove):
            b.setMinimumHeight(34)
        row_btns.addWidget(self.btn_ticket_add)
        row_btns.addWidget(self.btn_ticket_edit)
        row_btns.addWidget(self.btn_ticket_remove)
        left_col.addLayout(row_btns)
        vente_layout.addLayout(left_col, 2)

        # --- Totaux + Paiement à droite ---
        right_col = QVBoxLayout()
        totals_group = QGroupBox("Récapitulatif")
        grid = QGridLayout(totals_group)

        self.lbl_subtotal_ht = QLabel("Sous-total HTVA :")
        self.val_subtotal_ht = QLabel("0,00 €")
        self.lbl_tva_amount = QLabel("TVA totale :")
        self.val_tva_amount = QLabel("0,00 €")
        self.lbl_discount_percent = QLabel("Remise (%) :")
        self.input_discount_percent = QDoubleSpinBox()
        self.input_discount_percent.setRange(0.0, 100.0)
        self.input_discount_percent.setDecimals(2)
        self.input_discount_percent.setSuffix(" %")
        self.lbl_discount_amount = QLabel("Remise (€) :")
        self.input_discount_amount = QDoubleSpinBox()
        self.input_discount_amount.setRange(0.0, 1_000_000.0)
        self.input_discount_amount.setDecimals(2)
        self.input_discount_amount.setSuffix(" €")

        self.lbl_total_tvac = QLabel("TOTAL À PAYER (TVAC) :")
        self.lbl_total_tvac.setStyleSheet("font-size:18px;font-weight:800;")
        self.val_total_tvac = QLabel("0,00 €")
        self.val_total_tvac.setStyleSheet("font-size:22px;font-weight:900;color:#22c55e;")

        grid.addWidget(self.lbl_subtotal_ht, 0, 0)
        grid.addWidget(self.val_subtotal_ht, 0, 1, alignment=Qt.AlignRight)
        grid.addWidget(self.lbl_tva_amount, 1, 0)
        grid.addWidget(self.val_tva_amount, 1, 1, alignment=Qt.AlignRight)
        grid.addWidget(self.lbl_discount_percent, 2, 0)
        grid.addWidget(self.input_discount_percent, 2, 1)
        grid.addWidget(self.lbl_discount_amount, 3, 0)
        grid.addWidget(self.input_discount_amount, 3, 1)
        grid.addWidget(self.lbl_total_tvac, 4, 0)
        grid.addWidget(self.val_total_tvac, 4, 1, alignment=Qt.AlignRight)
        right_col.addWidget(totals_group)

        payment_group = QGroupBox("Paiement")
        pay = QGridLayout(payment_group)
        self.combo_payment = QComboBox()
        self.combo_payment.addItems(["Cash", "Bancontact", "Virement", "Crédit client"])
        self.input_received = QDoubleSpinBox()
        self.input_received.setRange(0.0, 1_000_000.0)
        self.input_received.setDecimals(2)
        self.input_received.setSuffix(" €")
        self.lbl_change = QLabel("Rendu :")
        self.val_change = QLabel("0,00 €")
        self.val_change.setStyleSheet("font-weight:800;")

        self.btn_finalize = QPushButton("Encaisser & Imprimer")
        self.btn_finalize.setMinimumHeight(42)
        self.btn_finalize.setStyleSheet("""
            QPushButton { background:#22c55e; color:#0b2113; border:none;
                          border-radius:8px; padding:10px 16px; font-weight:800; }
            QPushButton:hover { background:#16a34a; }
        """)

        pay.addWidget(QLabel("Méthode de paiement :"), 0, 0)
        pay.addWidget(self.combo_payment, 0, 1)
        pay.addWidget(QLabel("Montant reçu :"), 1, 0)
        pay.addWidget(self.input_received, 1, 1)
        pay.addWidget(self.lbl_change, 2, 0)
        pay.addWidget(self.val_change, 2, 1, alignment=Qt.AlignRight)
        pay.addWidget(self.btn_finalize, 3, 0, 1, 2)
        right_col.addWidget(payment_group)

        vente_layout.addLayout(right_col, 1)

        # ---------- Style global ----------
        MainWindow.setStyleSheet("""
            QMainWindow { background:#1E1E1E; }
            QLabel { color:white; }
            QTabWidget::pane { border:1px solid #2e2e2e; border-radius:8px; }
            QTabBar::tab { background:#2A2A2A; color:white; padding:8px 14px;
                           border-top-left-radius:6px; border-top-right-radius:6px; margin-right:2px; }
            QTabBar::tab:selected { background:#3A3A3A; }
            QScrollArea { border:none; }
        """)

        self.retranslateUi(MainWindow)
        QMetaObject.connectSlotsByName(MainWindow)

    def retranslateUi(self, MainWindow):
        MainWindow.setWindowTitle("SellGator - Tableau de bord")
