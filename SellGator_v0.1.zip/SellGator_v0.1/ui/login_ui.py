# -*- coding: utf-8 -*-
from PySide6.QtCore import *
from PySide6.QtGui import *
from PySide6.QtWidgets import *

class Ui_LoginForm(object):
    def setupUi(self, LoginForm):
        LoginForm.setObjectName("LoginForm")
        LoginForm.resize(400, 300)

        # --- Créer un widget central
        self.central_widget = QWidget(LoginForm)
        LoginForm.setCentralWidget(self.central_widget)

        # --- Layout vertical
        self.layout = QVBoxLayout(self.central_widget)
        self.layout.setContentsMargins(50, 40, 50, 40)
        self.layout.setSpacing(15)

        # --- Titre
        self.title_label = QLabel("SellGator", self.central_widget)
        self.title_label.setAlignment(Qt.AlignCenter)
        self.title_label.setStyleSheet("font-size: 26px; font-weight: bold; color: white;")
        self.layout.addWidget(self.title_label)

        # --- Champ email
        self.email_input = QLineEdit(self.central_widget)
        self.email_input.setPlaceholderText("Adresse email")
        self.email_input.setMinimumHeight(35)
        self.layout.addWidget(self.email_input)

        # --- Champ mot de passe
        self.password_input = QLineEdit(self.central_widget)
        self.password_input.setEchoMode(QLineEdit.Password)
        self.password_input.setPlaceholderText("Mot de passe")
        self.password_input.setMinimumHeight(35)
        self.layout.addWidget(self.password_input)

        # --- Bouton de connexion
        self.login_button = QPushButton("Se connecter", self.central_widget)
        self.login_button.setMinimumHeight(40)
        self.login_button.setStyleSheet(
            """
            QPushButton {
                background-color: #2E8B57;
                color: white;
                font-size: 16px;
                font-weight: bold;
                border-radius: 6px;
            }
            QPushButton:hover {
                background-color: #3CB371;
            }
            """
        )
        self.layout.addWidget(self.login_button)

        # --- Style global sombre (adapté à ton thème)
        LoginForm.setStyleSheet("""
            QMainWindow {
                background-color: #1E1E1E;
            }
            QLineEdit {
                background-color: #2A2A2A;
                color: white;
                border: 1px solid #555;
                border-radius: 5px;
                padding: 5px;
            }
            QLabel {
                color: white;
            }
        """)

        self.retranslateUi(LoginForm)
        QMetaObject.connectSlotsByName(LoginForm)

    def retranslateUi(self, LoginForm):
        LoginForm.setWindowTitle("Connexion - SellGator")
