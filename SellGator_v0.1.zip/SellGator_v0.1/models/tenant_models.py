from sqlalchemy import Column,Integer,String,Numeric,Float,ForeignKey,DateTime,Text
from sqlalchemy.orm import relationship
from datetime import datetime
from .base import Base
class Customer(Base):
    __tablename__='customers'
    id=Column(Integer,primary_key=True)
    type=Column(String(20),default='particulier')
    name=Column(String(255))
    vat=Column(String(32))
    email=Column(String(255))
    phone=Column(String(64))
class Product(Base):
    __tablename__='products'
    id=Column(Integer,primary_key=True)
    sku=Column(String(64))
    name=Column(String(255))
    vat_rate=Column(Float,default=21.0)
    price=Column(Numeric(10,2),default=0)
    stock_qty=Column(Integer,default=0)
