import sys
import sqlite3
from pathlib import Path

from PySide6.QtWidgets import (
    QApplication, QMainWindow, QMessageBox, QTableWidgetItem,
    QFileDialog, QInputDialog, QLabel, QPushButton,
    QTreeWidget, QTreeWidgetItem
)
from PySide6.QtGui import QIcon, QPixmap
from PySide6.QtCore import Qt, QSize

from core.settings import Settings
from core.auth import AuthService
from core.tenant import TenantContext

# Interfaces UI générées
from ui.login_ui import Ui_LoginForm
from ui.main_window_ui import Ui_MainWindow

BASE_DIR = Path(__file__).resolve().parent


# ----------------------------------------------------------------
#   Fenêtre de connexion
# ----------------------------------------------------------------
class LoginWindow(QMainWindow):
    def __init__(self, settings: Settings, auth: AuthService):
        super().__init__()
        self.settings = settings
        self.auth = auth
        self.ui = Ui_LoginForm()
        self.ui.setupUi(self)
        self.setWindowTitle("SellGator - Connexion")
        self.setWindowIcon(QIcon(str(BASE_DIR / "resources" / "logo_sg.png")))
        self.ui.login_button.clicked.connect(self.try_login)

    def try_login(self):
        email = self.ui.email_input.text().strip()
        password = self.ui.password_input.text().strip()
        user = self.auth.authenticate(email, password)
        if user:
            self.hide()
            self.main = MainWindow(self.settings, user)
            self.main.show()
        else:
            QMessageBox.warning(self, "Erreur", "Email ou mot de passe incorrect.")


# ----------------------------------------------------------------
#   Fenêtre principale
# ----------------------------------------------------------------
class MainWindow(QMainWindow):
    def __init__(self, settings: Settings, user):
        super().__init__()
        self.settings = settings
        self.user = user
        self.ui = Ui_MainWindow()
        self.ui.setupUi(self)
        self.setWindowTitle("SellGator - Tableau de bord")
        self.setWindowIcon(QIcon(str(BASE_DIR / "resources" / "logo_sg.png")))
        self.tenant_ctx = TenantContext(settings, user.tenant_db)

        # Ressources locales
        self.catalogue_images_dir = BASE_DIR / "catalogue_images"
        self.db_path = str(BASE_DIR / "catalogue.db")

        # État de navigation du catalogue (front)
        self.current_catalogue_level = "CAT"   # CAT → SUB → SEC → PROD
        self.current_parent_id = None

        # Infos utilisateur
        self.ui.label_user.setText(f"Connecté en tant que : {user.email}")
        self.ui.logout_button.clicked.connect(self.logout)

        # ---- NAV CATALOGUE (FRONT) ----
        self.ui.btn_back_nav.clicked.connect(self.catalogue_go_back)
        self.ui.btn_prev_section.clicked.connect(self.catalogue_prev_section)
        self.ui.btn_next_section.clicked.connect(self.catalogue_next_section)

        # ---- CAISSE / VENTE ----
        self.ticket_lines = []  # [{name, qty, price_ht, tva}, ...]
        self.ui.btn_ticket_add.clicked.connect(self.add_product_to_ticket)
        self.ui.btn_ticket_remove.clicked.connect(self.remove_selected_line)
        self.ui.input_discount_percent.valueChanged.connect(self.recalculate_totals)
        self.ui.input_discount_amount.valueChanged.connect(self.recalculate_totals)
        self.ui.input_received.valueChanged.connect(self.recalculate_change)
        self.ui.combo_payment.currentIndexChanged.connect(self.recalculate_change)
        self.refresh_ticket_table()
        self.update_totals_display(0, 0, 0, 0)

        # ---- BACK-OFFICE CATALOGUE ----
        self.ui.treeCatalog.itemSelectionChanged.connect(self.admin_on_selection_changed)
        self.ui.btn_admin_add.clicked.connect(self.admin_add_item)
        self.ui.btn_admin_rename.clicked.connect(self.admin_rename_item)
        self.ui.btn_admin_delete.clicked.connect(self.admin_delete_item)
        self.ui.btn_choose_image.clicked.connect(self.admin_choose_image)
        self.ui.btn_save_details.clicked.connect(self.admin_save_details)
        self.admin_set_details_enabled(False)
        self.load_admin_tree()

        # ---- FRONT CATALOGUE (chargement initial) ----
        self.load_catalogue_level("CAT")

    # ----------------------------------------------------------------
    #   CAISSE / VENTE
    # ----------------------------------------------------------------
    def add_product_to_ticket(self):
        # Placeholder (en v0.7 on ajoutera via sélection du catalogue)
        product = {"name": "Tube PVC 32mm", "qty": 1, "price_ht": 3.50, "tva": 21.0}
        self.ticket_lines.append(product)
        self.refresh_ticket_table()
        self.recalculate_totals()

    def remove_selected_line(self):
        row = self.ui.tableTicket.currentRow()
        if row >= 0:
            del self.ticket_lines[row]
            self.refresh_ticket_table()
            self.recalculate_totals()

    def refresh_ticket_table(self):
        t = self.ui.tableTicket
        t.setRowCount(0)
        for l in self.ticket_lines:
            total_ht = l["price_ht"] * l["qty"]
            total_tva = total_ht * (l["tva"] / 100.0)
            total_tvac = total_ht + total_tva
            r = t.rowCount()
            t.insertRow(r)
            vals = [
                l["name"], f"{l['qty']}", f"{l['price_ht']:.2f} €",
                f"{l['tva']:.0f} %", f"{total_ht:.2f} €",
                f"{total_tva:.2f} €", f"{total_tvac:.2f} €"
            ]
            for c, val in enumerate(vals):
                it = QTableWidgetItem(val)
                it.setTextAlignment(Qt.AlignCenter)
                t.setItem(r, c, it)

    def recalculate_totals(self):
        subtotal_ht = sum(l["price_ht"] * l["qty"] for l in self.ticket_lines)
        total_tva = sum((l["price_ht"] * l["qty"]) * (l["tva"] / 100.0) for l in self.ticket_lines)
        total_tvac = subtotal_ht + total_tva

        rem_pct = self.ui.input_discount_percent.value()
        rem_eur = self.ui.input_discount_amount.value()
        discount_val = total_tvac * (rem_pct / 100.0) if rem_pct > 0 else rem_eur
        total_final = max(total_tvac - discount_val, 0.0)

        self.update_totals_display(subtotal_ht, total_tva, total_tvac, total_final)
        self.recalculate_change()

    def update_totals_display(self, ht, tva, tvac, total_final):
        self.ui.val_subtotal_ht.setText(f"{ht:,.2f} €")
        self.ui.val_tva_amount.setText(f"{tva:,.2f} €")
        self.ui.val_total_tvac.setText(f"{total_final:,.2f} €")

    def recalculate_change(self):
        total_txt = (
            self.ui.val_total_tvac.text()
            .replace("€", "")
            .replace("\u202f", "")
            .replace(" ", "")
            .strip()
            .replace(",", ".")
        )
        try:
            total_value = float(total_txt)
        except Exception:
            total_value = 0.0

        received = self.ui.input_received.value()
        method = self.ui.combo_payment.currentText()
        change = max(received - total_value, 0.0) if method == "Cash" else 0.0
        self.ui.val_change.setText(f"{change:,.2f} €")

    # ----------------------------------------------------------------
    #   BACK-OFFICE : CATALOGUE CRUD
    # ----------------------------------------------------------------
    def load_admin_tree(self):
        """Recharge l'arborescence Cat → Sub → Sec → Prod et crée les tables si besoin."""
        self.ui.treeCatalog.clear()

        con = sqlite3.connect(self.db_path)
        cur = con.cursor()

        # Tables
        cur.execute("CREATE TABLE IF NOT EXISTS categories(id INTEGER PRIMARY KEY, name TEXT, image TEXT)")
        cur.execute("""CREATE TABLE IF NOT EXISTS subcategories(
                        id INTEGER PRIMARY KEY, name TEXT, image TEXT, category_id INT)""")
        cur.execute("""CREATE TABLE IF NOT EXISTS sections(
                        id INTEGER PRIMARY KEY, name TEXT, image TEXT, subcategory_id INT)""")
        cur.execute("""CREATE TABLE IF NOT EXISTS products(
                        id INTEGER PRIMARY KEY, name TEXT, image TEXT,
                        price_buy REAL, price_sell_ht REAL, tva REAL, section_id INT)""")
        con.commit()

        # Arbre
        cur.execute("SELECT id, name FROM categories ORDER BY name")
        for cid, cname in cur.fetchall():
            cat = self.add_tree_item(None, cname, "CAT", cid)
            cur.execute("SELECT id, name FROM subcategories WHERE category_id=? ORDER BY name", (cid,))
            for sid, sname in cur.fetchall():
                sub = self.add_tree_item(cat, sname, "SUB", sid)
                cur.execute("SELECT id, name FROM sections WHERE subcategory_id=? ORDER BY name", (sid,))
                for sec_id, sec_name in cur.fetchall():
                    sec = self.add_tree_item(sub, sec_name, "SEC", sec_id)
                    cur.execute("SELECT id, name FROM products WHERE section_id=? ORDER BY name", (sec_id,))
                    for pid, pname in cur.fetchall():
                        self.add_tree_item(sec, pname, "PROD", pid)

        self.ui.treeCatalog.expandAll()
        con.close()

    def add_tree_item(self, parent, name, typ, obj_id):
        item = QTreeWidgetItem([name, typ, str(obj_id)])
        if parent:
            parent.addChild(item)
        else:
            self.ui.treeCatalog.addTopLevelItem(item)
        return item

    def admin_on_selection_changed(self):
        """Remplit le panneau de détails selon l'élément sélectionné."""
        items = self.ui.treeCatalog.selectedItems()
        if not items:
            self.admin_set_details_enabled(False)
            self.ui.edit_name.clear()
            self.ui.edit_image_path.clear()
            self.ui.spin_buy.setValue(0)
            self.ui.spin_sell.setValue(0)
            self.ui.spin_tva.setValue(0)
            return

        item = items[0]
        typ, obj_id = item.text(1), int(item.text(2))
        self.admin_set_details_enabled(True, is_product=(typ == "PROD"))

        con = sqlite3.connect(self.db_path)
        cur = con.cursor()

        if typ == "CAT":
            cur.execute("SELECT name, image FROM categories WHERE id=?", (obj_id,))
            name, img = cur.fetchone()
            self.ui.edit_name.setText(name)
            self.ui.edit_image_path.setText(img or "")
            self.ui.spin_buy.setValue(0); self.ui.spin_sell.setValue(0); self.ui.spin_tva.setValue(0)

        elif typ == "SUB":
            cur.execute("SELECT name, image FROM subcategories WHERE id=?", (obj_id,))
            name, img = cur.fetchone()
            self.ui.edit_name.setText(name)
            self.ui.edit_image_path.setText(img or "")
            self.ui.spin_buy.setValue(0); self.ui.spin_sell.setValue(0); self.ui.spin_tva.setValue(0)

        elif typ == "SEC":
            cur.execute("SELECT name, image FROM sections WHERE id=?", (obj_id,))
            name, img = cur.fetchone()
            self.ui.edit_name.setText(name)
            self.ui.edit_image_path.setText(img or "")
            self.ui.spin_buy.setValue(0); self.ui.spin_sell.setValue(0); self.ui.spin_tva.setValue(0)

        elif typ == "PROD":
            cur.execute("SELECT name, image, price_buy, price_sell_ht, tva FROM products WHERE id=?", (obj_id,))
            name, img, buy, sell, tva = cur.fetchone()
            self.ui.edit_name.setText(name)
            self.ui.edit_image_path.setText(img or "")
            self.ui.spin_buy.setValue(buy or 0)
            self.ui.spin_sell.setValue(sell or 0)
            self.ui.spin_tva.setValue(tva or 0)

        con.close()

    def admin_set_details_enabled(self, enabled: bool, is_product: bool = False):
        self.ui.edit_name.setEnabled(enabled)
        self.ui.edit_image_path.setEnabled(False)
        self.ui.btn_choose_image.setEnabled(enabled)
        # Champs prix visibles uniquement pour PRODUIT
        self.ui.spin_buy.setEnabled(enabled and is_product)
        self.ui.spin_sell.setEnabled(enabled and is_product)
        self.ui.spin_tva.setEnabled(enabled and is_product)
        self.ui.btn_save_details.setEnabled(enabled)

    def admin_add_item(self):
        """Ajoute selon la sélection : (vide→CAT) / CAT→SUB / SUB→SEC / SEC→PROD."""
        items = self.ui.treeCatalog.selectedItems()
        typ = items[0].text(1) if items else None
        parent_id = int(items[0].text(2)) if items else None

        name, ok = QInputDialog.getText(self, "Ajouter", "Nom :")
        if not ok or not name.strip():
            return
        name = name.strip()

        con = sqlite3.connect(self.db_path)
        cur = con.cursor()

        if not typ:
            cur.execute("INSERT INTO categories(name, image) VALUES(?, ?)", (name, None))
        elif typ == "CAT":
            cur.execute("INSERT INTO subcategories(name, image, category_id) VALUES(?,?,?)", (name, None, parent_id))
        elif typ == "SUB":
            cur.execute("INSERT INTO sections(name, image, subcategory_id) VALUES(?,?,?)", (name, None, parent_id))
        elif typ == "SEC":
            cur.execute("""INSERT INTO products(name, image, price_buy, price_sell_ht, tva, section_id)
                           VALUES(?,?,?,?,?,?)""", (name, None, 0.0, 0.0, 21.0, parent_id))
        con.commit(); con.close()
        self.load_admin_tree()

    def admin_rename_item(self):
        items = self.ui.treeCatalog.selectedItems()
        if not items:
            return
        item = items[0]
        typ, obj_id = item.text(1), int(item.text(2))
        new_name, ok = QInputDialog.getText(self, "Renommer", "Nouveau nom :", text=item.text(0))
        if not ok or not new_name.strip():
            return
        new_name = new_name.strip()

        con = sqlite3.connect(self.db_path)
        cur = con.cursor()
        table = {"CAT": "categories", "SUB": "subcategories", "SEC": "sections", "PROD": "products"}[typ]
        cur.execute(f"UPDATE {table} SET name=? WHERE id=?", (new_name, obj_id))
        con.commit(); con.close()
        self.load_admin_tree()

    def admin_delete_item(self):
        items = self.ui.treeCatalog.selectedItems()
        if not items:
            return
        item = items[0]
        typ, obj_id = item.text(1), int(item.text(2))

        # Suppressions silencieuses (pas de pop-up)
        con = sqlite3.connect(self.db_path)
        cur = con.cursor()
        if typ == "PROD":
            cur.execute("DELETE FROM products WHERE id=?", (obj_id,))
        elif typ == "SEC":
            cur.execute("DELETE FROM products WHERE section_id=?", (obj_id,))
            cur.execute("DELETE FROM sections WHERE id=?", (obj_id,))
        elif typ == "SUB":
            cur.execute("SELECT id FROM sections WHERE subcategory_id=?", (obj_id,))
            for (sec_id,) in cur.fetchall():
                cur.execute("DELETE FROM products WHERE section_id=?", (sec_id,))
            cur.execute("DELETE FROM sections WHERE subcategory_id=?", (obj_id,))
            cur.execute("DELETE FROM subcategories WHERE id=?", (obj_id,))
        elif typ == "CAT":
            cur.execute("SELECT id FROM subcategories WHERE category_id=?", (obj_id,))
            for (sid,) in cur.fetchall():
                cur.execute("SELECT id FROM sections WHERE subcategory_id=?", (sid,))
                for (sec_id,) in cur.fetchall():
                    cur.execute("DELETE FROM products WHERE section_id=?", (sec_id,))
                cur.execute("DELETE FROM sections WHERE subcategory_id=?", (sid,))
            cur.execute("DELETE FROM subcategories WHERE category_id=?", (obj_id,))
            cur.execute("DELETE FROM categories WHERE id=?", (obj_id,))
        con.commit(); con.close()
        self.load_admin_tree()

    def admin_choose_image(self):
        file, _ = QFileDialog.getOpenFileName(self, "Choisir une image", "", "Images (*.png *.jpg *.jpeg)")
        if not file:
            return
        self.catalogue_images_dir.mkdir(parents=True, exist_ok=True)
        dest = self.catalogue_images_dir / Path(file).name
        import shutil
        shutil.copy(file, dest)
        self.ui.edit_image_path.setText(Path(file).name)

    def admin_save_details(self):
        items = self.ui.treeCatalog.selectedItems()
        if not items:
            return
        item = items[0]
        typ, obj_id = item.text(1), int(item.text(2))
        name = self.ui.edit_name.text().strip()
        image = self.ui.edit_image_path.text().strip() or None

        con = sqlite3.connect(self.db_path)
        cur = con.cursor()
        if typ == "PROD":
            buy = float(self.ui.spin_buy.value())
            sell = float(self.ui.spin_sell.value())
            tva = float(self.ui.spin_tva.value())
            cur.execute("""UPDATE products
                           SET name=?, image=?, price_buy=?, price_sell_ht=?, tva=? WHERE id=?""",
                        (name, image, buy, sell, tva, obj_id))
        else:
            table = {"CAT": "categories", "SUB": "subcategories", "SEC": "sections"}[typ]
            cur.execute(f"UPDATE {table} SET name=?, image=? WHERE id=?", (name, image, obj_id))
        con.commit(); con.close()
        self.load_admin_tree()

    # ----------------------------------------------------------------
    #   FRONT : CATALOGUE (affichage dynamique + navigation)
    # ----------------------------------------------------------------
    def load_catalogue_level(self, level="CAT", parent_id=None):
        """Charge Cat / Sub / Sec / Prod dans la grille front, depuis SQLite."""
        # Nettoyer la grille
        grid = self.ui.grid_catalogue
        for i in reversed(range(grid.count())):
            w = grid.itemAt(i).widget()
            if w:
                w.deleteLater()

        # Requête
        con = sqlite3.connect(self.db_path)
        cur = con.cursor()
        if level == "CAT":
            cur.execute("SELECT id, name, image FROM categories ORDER BY name")
        elif level == "SUB":
            cur.execute("SELECT id, name, image FROM subcategories WHERE category_id=? ORDER BY name", (parent_id,))
        elif level == "SEC":
            cur.execute("SELECT id, name, image FROM sections WHERE subcategory_id=? ORDER BY name", (parent_id,))
        elif level == "PROD":
            cur.execute("""SELECT id, name, image, price_sell_ht, tva
                           FROM products WHERE section_id=? ORDER BY name""", (parent_id,))
        else:
            con.close()
            return
        results = cur.fetchall()
        con.close()

        if not results:
            lbl = QLabel("Aucun élément à afficher.")
            lbl.setStyleSheet("color:#aaa; font-size:14px;")
            lbl.setAlignment(Qt.AlignCenter)
            grid.addWidget(lbl, 0, 0)
            self.current_catalogue_level = level
            self.current_parent_id = parent_id
            return

        # Affichage en grille (3 colonnes)
        cols = 3
        for i, row in enumerate(results):
            if level == "PROD":
                pid, name, image, price, tva = row
            else:
                pid, name, image = row[0], row[1], row[2]

            btn = QPushButton()
            btn.setCursor(Qt.PointingHandCursor)
            btn.setFixedSize(230, 230)
            btn.setStyleSheet("""
                QPushButton {
                    background:#2b2b2b; border:1px solid #3a3a3a; border-radius:10px;
                    color:white; font-size:14px; padding:8px;
                }
                QPushButton:hover { background:#363636; }
            """)

            # Image (silencieux si absente)
            img_ok = False
            if image:
                img_path = self.catalogue_images_dir / image
                if img_path.exists():
                    pix = QPixmap(str(img_path)).scaled(180, 140, Qt.KeepAspectRatio, Qt.SmoothTransformation)
                    btn.setIcon(QIcon(pix))
                    btn.setIconSize(QSize(pix.width(), pix.height()))
                    img_ok = True
            if not img_ok:
                # Optionnel : icône placeholder si disponible
                ph = BASE_DIR / "resources" / "placeholder.png"
                if ph.exists():
                    pix = QPixmap(str(ph)).scaled(100, 100, Qt.KeepAspectRatio, Qt.SmoothTransformation)
                    btn.setIcon(QIcon(pix))
                    btn.setIconSize(QSize(pix.width(), pix.height()))

            # Texte
            text = name
            if level == "PROD":
                text += f"\n{price:.2f} € HT ({tva:.0f}%)"
            btn.setText(text)
            btn.setToolTip(name)

            # Clic
            btn.clicked.connect(lambda _, nid=pid, lvl=level: self.catalogue_item_clicked(lvl, nid))

            r, c = divmod(i, cols)
            grid.addWidget(btn, r, c)

        self.current_catalogue_level = level
        self.current_parent_id = parent_id

    def catalogue_item_clicked(self, level, item_id):
        """Navigation descendante par clic sur un item."""
        if level == "CAT":
            self.load_catalogue_level("SUB", item_id)
        elif level == "SUB":
            self.load_catalogue_level("SEC", item_id)
        elif level == "SEC":
            self.load_catalogue_level("PROD", item_id)
        elif level == "PROD":
            # v0.7 : fiche produit / variantes
            pass

    # ---- Boutons de navigation (fluide, sans popups) ----
    def catalogue_go_back(self):
        """Remonte d'un niveau dans la hiérarchie (silencieusement)."""
        lvl = getattr(self, "current_catalogue_level", "CAT")
        parent = getattr(self, "current_parent_id", None)

        if lvl == "CAT":
            return
        elif lvl == "SUB":
            self.load_catalogue_level("CAT")
        elif lvl == "SEC":
            con = sqlite3.connect(self.db_path)
            cur = con.cursor()
            cur.execute("SELECT category_id FROM subcategories WHERE id=?", (parent,))
            row = cur.fetchone()
            con.close()
            self.load_catalogue_level("SUB", row[0] if row else None)
        elif lvl == "PROD":
            con = sqlite3.connect(self.db_path)
            cur = con.cursor()
            cur.execute("SELECT subcategory_id FROM sections WHERE id=?", (parent,))
            row = cur.fetchone()
            con.close()
            self.load_catalogue_level("SEC", row[0] if row else None)

    def catalogue_prev_section(self):
        """Section précédente (si on est au niveau SEC → passer à la liste de produits de la section précédente)."""
        if getattr(self, "current_catalogue_level", None) != "SEC":
            return
        con = sqlite3.connect(self.db_path)
        cur = con.cursor()
        cur.execute("SELECT subcategory_id FROM sections WHERE id=?", (self.current_parent_id,))
        row = cur.fetchone()
        if not row:
            con.close(); return
        sub_id = row[0]
        cur.execute("SELECT id FROM sections WHERE subcategory_id=? ORDER BY id", (sub_id,))
        secs = [r[0] for r in cur.fetchall()]
        con.close()
        if self.current_parent_id in secs:
            idx = secs.index(self.current_parent_id)
            if idx > 0:
                self.load_catalogue_level("PROD", secs[idx - 1])

    def catalogue_next_section(self):
        """Section suivante (si on est au niveau SEC → passer à la liste de produits de la section suivante)."""
        if getattr(self, "current_catalogue_level", None) != "SEC":
            return
        con = sqlite3.connect(self.db_path)
        cur = con.cursor()
        cur.execute("SELECT subcategory_id FROM sections WHERE id=?", (self.current_parent_id,))
        row = cur.fetchone()
        if not row:
            con.close(); return
        sub_id = row[0]
        cur.execute("SELECT id FROM sections WHERE subcategory_id=? ORDER BY id", (sub_id,))
        secs = [r[0] for r in cur.fetchall()]
        con.close()
        if self.current_parent_id in secs:
            idx = secs.index(self.current_parent_id)
            if idx < len(secs) - 1:
                self.load_catalogue_level("PROD", secs[idx + 1])

    # ----------------------------------------------------------------
    #   Divers
    # ----------------------------------------------------------------
    def logout(self):
        self.close()
        self.login = LoginWindow(self.settings, AuthService(self.settings))
        self.login.show()


# ----------------------------------------------------------------
#   Lancement
# ----------------------------------------------------------------
if __name__ == "__main__":
    app = QApplication(sys.argv)
    settings = Settings()
    auth = AuthService(settings)
    login = LoginWindow(settings, auth)
    login.show()
    sys.exit(app.exec())
