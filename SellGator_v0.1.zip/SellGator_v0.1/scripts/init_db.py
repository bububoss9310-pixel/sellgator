"""
Initialisation de la base SellGator :
- crée les bases `sellgator_auth` et `client_demo`
- crée les tables d'authentification
- ajoute un utilisateur de test : demo@sellgator.local / demo1234
"""

from core.settings import Settings
from core.db import make_mysql_engine
from sqlalchemy import text, select, insert
from argon2 import PasswordHasher
from core.auth import AuthService
from core.tenant import TenantContext

TENANT_DB = "client_demo"
EMAIL = "demo@sellgator.local"
PASSWORD = "demo1234"

settings = Settings()
cfg = settings.auth_db

# Connexion MySQL principale (root)
root_engine = make_mysql_engine(
    cfg["host"], cfg.get("port", 3306), cfg["user"], cfg["password"], "mysql"
)

print("Connexion à MySQL réussie.")
with root_engine.connect() as con:
    con.execute(
        text(
            "CREATE DATABASE IF NOT EXISTS sellgator_auth CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci"
        )
    )
    con.execute(
        text(
            f"CREATE DATABASE IF NOT EXISTS {TENANT_DB} CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci"
        )
    )
    print("Bases de données créées ou déjà existantes.")

# Crée les tables d’authentification et l’utilisateur de test
svc = AuthService(settings)
ph = PasswordHasher()

with svc.engine.begin() as con:
    res = con.execute(
        select(svc.users.c.id).where(svc.users.c.email == EMAIL)
    ).fetchone()
    if not res:
        con.execute(
            insert(svc.users).values(
                email=EMAIL,
                password_hash=ph.hash(PASSWORD),
                role="admin",
                tenant_db=TENANT_DB,
                is_active=True,
            )
        )
        print(f"Utilisateur de test ajouté : {EMAIL} / {PASSWORD}")
    else:
        print("Utilisateur déjà présent dans la base.")

# Crée les tables du tenant (client_demo)
TenantContext(settings, TENANT_DB)
print("Base client_demo initialisée avec succès.")
