from dataclasses import dataclass
from sqlalchemy import Table, Column, Integer, String, Boolean, MetaData, select
from argon2 import PasswordHasher
from .db import make_mysql_engine, make_session


@dataclass
class AuthService:
    settings: any

    def __post_init__(self):
        cfg = self.settings.auth_db
        self.engine = make_mysql_engine(
            cfg["host"],
            cfg.get("port", 3306),
            cfg["user"],
            cfg["password"],
            cfg["database"],
        )
        self.meta = MetaData()
        self.users = Table(
            "users",
            self.meta,
            Column("id", Integer, primary_key=True),
            Column("email", String(255), unique=True),
            Column("password_hash", String(255)),
            Column("role", String(32)),
            Column("tenant_db", String(255)),
            Column("is_active", Boolean, default=True),
        )
        self.meta.create_all(self.engine)
        self.hasher = PasswordHasher()

    def verify_credentials(self, email, pwd):
        """Ancienne fonction de vérif (gardée pour compatibilité interne)"""
        s = make_session(self.engine)
        row = s.execute(select(self.users).where(self.users.c.email == email)).fetchone()
        if not row:
            return False, "Utilisateur inconnu"
        u = row._mapping
        try:
            self.hasher.verify(u["password_hash"], pwd)
        except Exception:
            return False, "Mot de passe invalide"
        if not u["is_active"]:
            return False, "Compte désactivé"
        return True, {
            "tenant_db": u["tenant_db"],
            "role": u["role"],
            "email": u["email"],
        }

    def authenticate(self, email: str, password: str):
        """Nouvelle fonction utilisée par l'écran de connexion"""
        s = make_session(self.engine)
        row = s.execute(select(self.users).where(self.users.c.email == email)).fetchone()
        if not row:
            print(f"[Auth] Utilisateur introuvable : {email}")
            return None

        user = row._mapping
        try:
            self.hasher.verify(user["password_hash"], password)
        except Exception:
            print(f"[Auth] Mot de passe invalide pour : {email}")
            return None

        if not user["is_active"]:
            print(f"[Auth] Compte désactivé : {email}")
            return None

        print(f"[Auth] Connexion réussie : {email}")
        return user
