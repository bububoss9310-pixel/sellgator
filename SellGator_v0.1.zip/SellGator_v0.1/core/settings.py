from pathlib import Path
import yaml
class Settings:
    def __init__(self, cfg_path=None):
        base = Path(__file__).resolve().parents[1]
        path = Path(cfg_path) if cfg_path else base/'config.yaml'
        if not path.exists():
            path = base/'config.yaml.example'
        self.cfg = yaml.safe_load(open(path,'r',encoding='utf-8'))
    @property
    def auth_db(self): return self.cfg.get('auth_db',{})
