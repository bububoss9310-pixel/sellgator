from dataclasses import dataclass
from .db import make_mysql_engine,make_session
from models.base import Base
from models import tenant_models
@dataclass
class TenantContext:
    settings:any
    tenant_db:str
    def __post_init__(self):
        cfg=self.settings.auth_db
        self.engine=make_mysql_engine(cfg['host'],cfg.get('port',3306),cfg['user'],cfg['password'],self.tenant_db)
        Base.metadata.create_all(self.engine)
        self.session=make_session(self.engine)
