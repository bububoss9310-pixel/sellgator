from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
def make_mysql_engine(h,p,u,pw,db):
    return create_engine(f'mysql://{u}:{pw}@{h}:{p}/{db}?charset=utf8mb4',pool_pre_ping=True)
def make_session(engine): return sessionmaker(bind=engine)()
