from weasyprint import HTML
def render_pdf(path,html):
    HTML(string=html).write_pdf(path)
